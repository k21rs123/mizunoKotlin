package jp.ac.kyusanu.nicetomeetyou

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityStopWatchBinding
import java.text.SimpleDateFormat
import java.util.Locale

class StopWatchActivity : AppCompatActivity() {//stopのSを大文字に

    private lateinit var binding: ActivityStopWatchBinding

   /* companion object{//JavaのStaticと同じようなものインスタンスを生成しなくて良くなる
        private const val termMilliSecond: Long = 100 //0.1秒 Long= ６４Bit整数
        //constをつけるとgetTermMilliSecondと書かなくて良くなる　？
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stop_watch)
        binding = ActivityStopWatchBinding.inflate(layoutInflater)

        val view = binding.root
        setContentView(view)

        //ボタンの有効無効を設定
        binding.startButton.isEnabled = true
        binding.stopButton.isEnabled = false
        binding.resetButton1.isEnabled = false

        var time = 0L//時間を測る変数
        val dataFormat = SimpleDateFormat("mm:ss.S", Locale.JAPAN)//値を日時の書式に変換する。

        val sharedPref = getSharedPreferences("Datastore", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        val handler = Handler(Looper .getMainLooper())//Handler：Looperに対してRunnableオブジェクトの送信および処理
        // Looper：無限ループしながら自分が属した（handler)スレッドのRunnableをHandlerに処理してもらう
        val timer = object : Runnable{
            //override: 既存のクラスを継承すること　Runnableを継承
            override fun run(){
                time += 100
                binding.stopWatchText.text = dataFormat.format(time)
                //r=実行されるRunnable　今回は自分自身なのでthis
                handler.postDelayed(this, 100)//timerの処理をtermMillisecond後(０.1秒後）に行う
            }
        }
        //スタート
        binding.startButton.setOnClickListener{
            handler.post(timer)//handlerでTimerを追加して、実行
            binding.startButton.isEnabled = false//スタートボタンの無効化
            binding.resetButton1.isEnabled = true
            binding.stopButton.isEnabled = true//ストップボタンの有効化

        }
        //ストップ
        binding.stopButton.setOnClickListener{
            handler.removeCallbacks(timer)//timerの実行を削除
            binding.startButton.isEnabled = true//スタートボタンの有効化
            binding.stopButton.isEnabled = false//ストップボタンの無効化
        }
        //ラップ
        binding.lapButton.setOnClickListener{
            binding.lapView.text = dataFormat.format(time)
            binding.lapText.setText(R.string.stop_watch_lap)
            editor.putLong("Time",time)
            editor.apply()
        }
        //リセット
        binding.resetButton1.setOnClickListener{
            handler.removeCallbacks(timer)//timerの実行を削除
            binding.startButton.isEnabled = true
            binding.resetButton1.isEnabled = false
            time = 0L
            binding.stopWatchText.text = dataFormat.format(time)
            binding.lapText.text = ""
            binding.lapView.text = ""

            binding.stopButton.isEnabled = false//ストップボタンの無効化
        }

        binding.stopWatchReturnButton.setOnClickListener{
            finish()
        }
    }
}