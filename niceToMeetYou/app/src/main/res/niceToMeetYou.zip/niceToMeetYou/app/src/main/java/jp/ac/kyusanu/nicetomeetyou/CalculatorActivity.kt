package jp.ac.kyusanu.nicetomeetyou

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityCalculatorBinding
import kotlin.math.sqrt
import java.text.DecimalFormat

class CalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCalculatorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        binding = ActivityCalculatorBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //数値を保持する変数
        var value = 0.0

        //小数点をまとめる
        val df = DecimalFormat("#.########")

        //新しく数値を入れていいかのフラグ
        var clear = false

        //演算子を押した後に数字を押すなど計算を行うかを判断するフラグ
        var calc = false

        //実行予定の演算子を保持しておく変数
        var operator = "no" //演算子を未選択状態

        //小数点　decimal point
        var dec = false

//関数の宣言

        //数字ボタンを押した時の関数
        fun numButtonAction(num :Int) {
            //acが無効かつテキストが０以外であれば
            binding.result.text = if(binding.result.text.toString() != "0" && !clear){
                binding.result.text.toString() + num.toString()
            } else {
                clear = false
                dec = false
                num.toString()
            }
            calc = true
        }

        //+/-が押されたとき値の正と負を入れ替え
        fun plusMinusButtonAction(){
            if(binding.result.text.toString() != "0"){//テキストが０以外であれば
                val y = -binding.result.text.toString().toDouble()
                value = y
                binding.result.text = df.format(y).toString()
            }
        }

        //.が押されたとき
        fun dotButtonAction(){
            binding.result.text = if(!dec){
                binding.result.text.toString() + "."

            }else{
                binding.result.text
            }
            dec = true
        }

        //計算を実行する際の演算子を確認する
        fun calculation(op : String) :Double {
            // else 以外の場所は全て演算子を一回は押したときに運ばれてくる場所
            return when (op) {
                "+" -> {
                    value + binding.result.text.toString().toDouble()
                }
                "-" -> {
                    value - binding.result.text.toString().toDouble()
                }
                "*" -> {
                    value * binding.result.text.toString().toDouble()
                }
                "/" -> {
                    value / binding.result.text.toString().toDouble()
                }
                "^" -> {
                    val x = binding.result.text.toString().toInt()
                    val y = value
                    for(i in 1 until x){
                        value *= y
                    }
                    //計算後のvalueを返す
                    value
                }
                else -> {//最初に演算子を選択したときに数値が運ばれてくる場所
                    binding.result.text.toString().toDouble()
                }
            }
        }

        //計算の行う時の処理
        fun calcButtonAction(op : String) {

            if (calc) { //calc == true
                value = calculation(operator)
                clear = true
                calc = false
                binding.result.text = df.format(value).toString()
            }
            operator = op
        }

        //√ボタンを押した時の処理
        fun sqrtButtonAction(){//sqrt関数　ルート計算する
            if(binding.result.text.toString().toDouble() > 0 ) {
                val sqrtNum: Double = sqrt(binding.result.text.toString().toDouble())
                binding.result.text = df.format(sqrtNum).toString()
                clear = true
            }

        }

        //イコールボタンを押した時の関数
        fun equalButtonAction() {
            if (calc) { //calc == true
                value = calculation(operator)
                calc = false
                clear = true
                binding.result.text = df.format(value).toString()
                operator = "no" //演算子を未選択
            }
        }

        //ACを押した時の関数
        fun allClearButtonAction(){
            binding.result.text ="0"
            value = 0.0
            operator = "no" //演算子を未選択
            clear = false
            calc = false
            dec = false
        }

//ボタンが押されたことを検知する処理
        //0
        binding.zero.setOnClickListener {
            numButtonAction(0)
        }
        //1
        binding.one.setOnClickListener {
            numButtonAction(1)
        }
        //2
        binding.two.setOnClickListener {
            numButtonAction(2)
        }
        //3
        binding.three.setOnClickListener {
            numButtonAction(3)
        }
        //4
        binding.four.setOnClickListener {
            numButtonAction(4)
        }
        //5
        binding.five.setOnClickListener {
            numButtonAction(5)
        }
        //6
        binding.six.setOnClickListener {
            numButtonAction(6)
        }
        //7
        binding.seven.setOnClickListener {
            numButtonAction(7)
        }
        //8
        binding.eight.setOnClickListener {
            numButtonAction(8)
        }
        //9
        binding.nine.setOnClickListener {
            numButtonAction(9)
        }
        //+
        binding.add.setOnClickListener {
            calcButtonAction("+")
            binding.preview.text = "+"
        }
        //-
        binding.sub.setOnClickListener {
            calcButtonAction("-")
            binding.preview.text = "-"
        }
        //×
        binding.mul.setOnClickListener {
            calcButtonAction("*")
            binding.preview.text = "*"
        }
        //÷
        binding.div.setOnClickListener {
            calcButtonAction("/")
            binding.preview.text = "/"
        }
        //^
        binding.multiplier.setOnClickListener{
            calcButtonAction("^")
            binding.preview.text = "^"
        }
        //√
        binding.sqrt.setOnClickListener{
            sqrtButtonAction()
        }
        //.
        binding.dot.setOnClickListener{
            dotButtonAction()
            //binding.preview.text = "."
        }
        //+
        binding.state.setOnClickListener{
            plusMinusButtonAction()
        }
        //=
        binding.equal.setOnClickListener {
            equalButtonAction()
            binding.preview.text = ""
        }
        //AC
        binding.allClear.setOnClickListener {
            allClearButtonAction()
            binding.preview.text = ""
        }






        binding.calculatorReturnButton.setOnClickListener{
            finish()
        }

    }
}