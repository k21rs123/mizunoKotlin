package jp.ac.kyusanu.nicetomeetyou

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityIntroduceBinding

class IntroduceActivity : AppCompatActivity() {
    private lateinit var binding: ActivityIntroduceBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_introduce)
        binding = ActivityIntroduceBinding.inflate(layoutInflater)

        val view = binding.root
        setContentView(view)

        binding.introduceReturnButton.setOnClickListener{
            finish()
        }
    }
}