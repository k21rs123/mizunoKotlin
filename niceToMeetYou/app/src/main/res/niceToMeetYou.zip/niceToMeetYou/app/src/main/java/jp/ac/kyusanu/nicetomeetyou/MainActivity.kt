package jp.ac.kyusanu.nicetomeetyou

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)//Activity上に画面を構成する要素(binding.root)を表示する

        var intent:Intent

        binding.counterButton.setOnClickListener{
            intent = Intent(this,CounterActivity::class.java)
            startActivity(intent)//指定した遷移先に移動する
        }
        binding.stopWatchButton.setOnClickListener{
            intent = Intent(this,StopWatchActivity::class.java)
            startActivity(intent)
        }
        binding.introductionButton.setOnClickListener{
            intent = Intent(this,IntroduceActivity::class.java)
            startActivity(intent)
        }
        binding.calculatorButton.setOnClickListener{
            intent = Intent(this,CalculatorActivity::class.java)
            startActivity(intent)
        }
        binding.toDoListButton.setOnClickListener{
            intent = Intent(this,ToDoListActivity::class.java)
            startActivity(intent)
        }
        binding.timerButton.setOnClickListener{
            intent = Intent(this,TimerActivity::class.java)
            startActivity(intent)
        }
    }
}