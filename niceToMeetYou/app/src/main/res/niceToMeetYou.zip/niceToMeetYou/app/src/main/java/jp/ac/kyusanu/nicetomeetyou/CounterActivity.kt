package jp.ac.kyusanu.nicetomeetyou

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityCounterBinding

class CounterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCounterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_counter)
        binding = ActivityCounterBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //デバイス内にデータを保存するための仕組み　getSharePreferencesで保存先とモード の指定　Datastore.xmlに保存,　MODE_PRIVATE：このアプリからのみ書き込み可
        val sharedPref = getSharedPreferences("Datastore", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()//sharedPrefを編集をするためのeditorを作成
        var count = sharedPref.getInt("Count",0)//countに鍵がInputのデータを受け取る

        binding.countText.text = count.toString()
        reload(count)

        binding.plusButton.setOnClickListener{
            count ++
            editor.putInt("Count",count)//Inputにcountの値を追加
            editor.apply()//editorからSharedPreferencesの編集中のオブジェクトに書き込む
            binding.countText.text = count.toString()
            reload(count)
        }

        binding.minusButton.setOnClickListener{
            count --
            editor.putInt("Count",count)
            editor.apply()
            binding.countText.text = count.toString()
            reload(count)
        }

        binding.resetButton.setOnClickListener{
            count = 0
            editor.putInt("Count",count)
            editor.apply()
            binding.countText.text = count.toString()
            binding.countText.setTextColor(resources.getColor(R.color.white,theme))
        }

        binding.counterReturnButton.setOnClickListener{
            finish()
        }
    }

    //カウントの値によってカウントテキストの色を変更
    private fun reload(count:Int) {
        if(count < 0){
            binding.countText.setTextColor(resources.getColor(R.color.red,theme))
        }else{
            binding.countText.setTextColor(resources.getColor(R.color.white,theme))
        }
    }
}