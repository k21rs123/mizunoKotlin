package jp.ac.kyusanu.nicetomeetyou

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import jp.ac.kyusanu.nicetomeetyou.databinding.ActivityToDoListBinding
import org.json.JSONArray

class ToDoListActivity : AppCompatActivity() {
    private lateinit var binding : ActivityToDoListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do_list)
        binding = ActivityToDoListBinding.inflate(layoutInflater)

        val view = binding.root
        setContentView(view)

        val toDoArray:ArrayList<String> = loadArrayList()

        //追加できるリストの宣言　mutableListOfに型を指定する（String)
        val adapter = ArrayAdapter(//Contextクラスのオブジェクトの指定、テキストのリソース（スタイル？）の指定、保持するデータの一覧を表す配列の指定
            this,//このアクティヴィティを指定
            //simple_list_item_1をテキストのスタイルとして指定
            android.R.layout.simple_list_item_1,
            // mutableListOf()(変更可能な空のリスト)を保持するデータの一覧の配列として指定
            toDoArray
        )
        //リストビューにアダプターを代入
        binding.listView.adapter = adapter

        //＋ボタンを押した時の処理
        binding.addButton.setOnClickListener{
            //入力欄を作成　EditTextを当アクティビティに新規作成
            val editText = EditText(this)

            //予定の入力
            AlertDialog.Builder(this)//デフォルトのアラートダイアログテーマを使用するアラートダイアログのビルダーを作成
                //アラートダイアログのレイアウト設定
                .setTitle("リストの追加")//タイトル
                .setMessage("予定の入力")//メッセージ
                .setView(editText)//作成したeditTextを使用して入力欄表示

                //確定ボタン（アクションボタン）の作成    ダイアログのアイテムがクリックされたときに処理を実行出来る
                .setPositiveButton("追加"){ _, _ ->
                    val newToDo = editText.text.toString()//入力欄で入力した文字列を保存する変数

                    //保存された文字列をアダプターの中に追加
                    adapter.add(newToDo)
                    saveArrayList(toDoArray)

                }
                //キャンセルボタン　押されたら（null）何もしない
                .setNegativeButton("キャンセル",null)
                .show()//上のダイアログを表示
        }

        //リストビューをクリックした時の処理
        binding.listView.setOnItemClickListener{ _, _, i, _ ->
            //アラートダイアログを表示
            AlertDialog.Builder(this)
                .setTitle("削除しますか？")//タイトル
                //確定ボタンの作成　押されたら選択したリストを削除
                .setPositiveButton("削除"){ _, _ ->//使いたくない引数が指定される（ℹ︎）ので＿にリネーム
                    adapter.remove(adapter.getItem(i))//選択された配列のi番目のリストを削除
                    saveArrayList(toDoArray)
                }
                //キャンセルを押された時何も起こさない
                .setNegativeButton("キャンセル",null)
                .show()//上のダイアログを表示
        }

        binding.todoReturnButton.setOnClickListener{
            finish()
        }
    }
    private fun saveArrayList(arrayList: ArrayList<String>){
        val sharedPreferences = this.getPreferences(Context.MODE_PRIVATE)
        val shareDPrefEditor = sharedPreferences.edit()

        val jsonArray = JSONArray(arrayList)
        shareDPrefEditor.putString("todo", jsonArray.toString())
        shareDPrefEditor.apply()
    }
    private fun loadArrayList():ArrayList<String>{
        val sharedPreferences = this.getPreferences(Context.MODE_PRIVATE)
        val jsonArray = JSONArray(sharedPreferences.getString("todo","[]"))
        val arrayList : ArrayList<String> = ArrayList()

        for(i in 0 until jsonArray.length()){
            arrayList.add(jsonArray.get(i) as String)
        }
        return arrayList
    }
}